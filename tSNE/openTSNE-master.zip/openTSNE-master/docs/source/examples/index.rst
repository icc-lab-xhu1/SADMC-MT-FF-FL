How to use t-SNE
================

.. toctree::
    :maxdepth: 1

    01_simple_usage/01_simple_usage
    02_advanced_usage/02_advanced_usage
    03_preserving_global_structure/03_preserving_global_structure
    04_large_data_sets/04_large_data_sets
