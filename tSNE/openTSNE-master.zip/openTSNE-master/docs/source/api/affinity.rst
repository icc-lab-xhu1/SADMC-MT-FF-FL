Affinity
========

.. automodule:: openTSNE.affinity
    :members: Affinities, PerplexityBasedNN, MultiscaleMixture, Multiscale, FixedSigmaNN, Uniform, PrecomputedAffinities
    :undoc-members:
