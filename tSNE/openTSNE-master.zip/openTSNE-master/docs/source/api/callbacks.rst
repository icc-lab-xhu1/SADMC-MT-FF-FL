Callbacks
=========

.. automodule:: openTSNE.callbacks

    .. autoclass:: Callback
        :members: optimization_about_to_start
        :special-members: __call__
