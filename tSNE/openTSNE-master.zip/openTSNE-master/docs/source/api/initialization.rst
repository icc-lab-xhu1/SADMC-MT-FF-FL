Initialization
==============

.. automodule:: openTSNE.initialization
    :members: pca, spectral, random, rescale, jitter
